<?php
error_reporting(0);
session_start();
if (isset ($_POST['login'])) {
    $user = $_POST['username'];
    $pass = $_POST['password'];

    if ($user == 'cahyo' and $pass == '123') {
        //memnuat session
        session_start();
        $_SESSION['berhasil'] = true;
        
        
        header("location:zeusgacor.php");
        
    } else {
        $salah = " <p style='color: red;'>username dan password salah</p>";                
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="img/Travel Bali tidak (1500 x 800 piksel).png" type="image/x-icon">
    <title>Login</title>
    <style>
        body{
            display: flex;
            align-items: center;
            justify-content: center;

        }

        .login-card {
            width: 300px;
            margin: 160px 0px 0px 0px;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 10px;
            background-color: #e8e8e8;
            box-shadow: 2px 2px 10px #ccc;
        }

        .card-header {
            text-align: center;
            margin-bottom: 20px
        }

        .card-header .log {
            margin: 0;
            font-size: 24px;
            color: black;
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            font-size: 18px;
            margin-bottom: 5px;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 12px 20px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
            transition: 0.5s;
        }

        input[type="submit"] {
            width: 100%;
            background-color: #333;
            color: white;
            padding: 14px 20px;
            margin: 8px 0;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #ccc;
            color: black;
        }
    </style>
  
</head>

<body>

    <div class="login-card">
        <div class="card-header">
            <div class="log">Login</div>
            <?php echo $salah;?>
        </div>
        <form action="" method="post">
            <div class="form-group">
                <label for="username">Username:</label>
                <input required="" name="username" id="username" type="text">
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input required="" name="password" id="password" type="password">
            </div>
            <div class="form-group">
                <input value="Login" name="login" type="submit">
            </div>
        </form>
    </div>
</body>

</html>