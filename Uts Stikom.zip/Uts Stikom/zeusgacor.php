<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="img/logo.jpg" type="image/x-icon">
    <link rel="stylesheet" href="style.css">
    <title>Zeusgacor.com</title>
</head>
<body>
    <!-- Header -->
    <header>
        <div class="container flex justify-between align-center">
            <a href="index.html" class="logo">
                <img width="100px" src="img/creative-o-removebg-preview.png" alt="">Zeus.com
                <!-- <svg viewBox="0 0 24 24">
                    <path d="M12,2A10,10 0 0,1 22,12A10,10 0 0,1 12,22A10,10 0 0,1 2,12A10,10 0 0,1 12,2M12,4A8,8 0 0,0 4,12A8,8 0 0,0 12,20A8,8 0 0,0 20,12A8,8 0 0,0 12,4M7,10H9A2,2 0 0,1 11,12A2,2 0 0,1 9,14H7V10M11,10H14V11.5H11V10M11,12.5H14V14H11V12.5M15,10H17A2,2 0 0,1 19,12A2,2 0 0,1 17,14H15V10M7,15H19V17H7V15Z" />
                </svg>
                Nexcent -->
            </a>
            
            <div class="hamburger">
                <span></span>
                <span></span>
                <span></span>
            </div>
            
            <div class="nav-links">
                <nav>
                    <ul>
                        <li><a href="#">Home</a></li>
                        <li><a href="#features">Feature</a></li>
                        <li><a href="#stats">Service</a></li>
                        <!-- <li><a href="#">Product</a></li> -->
                        <!-- <li><a href="#">Testimonial</a></li> -->
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </nav>
                
                <!-- <div class="auth-buttons">
                    <button class="btn btn-outline login-btn">Login</button>
                    <button class="btn signup-btn">Sign Up</button>
                </div> -->
            </div>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="hero">
        <div class="container">
            <div class="carousel">
                <div class="carousel-inner">
                    <div class="carousel-item">
                        <div class="hero-content">
                            <div class="hero-text ">
                                <h1 style="color: red; text-shadow: 1px 2px 0px white;" >Auto Win<span class="highlight">Zeus gacor</span></h1>
                                <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Architecto reprehenderit exercitationem ducimus, illum nemo nobis cupiditate neque expedita eos vitae placeat? Laborum impedit rerum, facilis sed ipsam inventore qui? Officia.</p>
                                <a href="#"  class="btn">Register</a>
                            </div>
                            <div class="hero-image">
                                <!-- <img src="removebg.png" alt="Hero Image"> -->
                            </div>
                        </div>
                    </div>
                </div>
                <!-- <div class="carousel-dots">
                    <div class="dot active"></div>
                    <div class="dot"></div>
                    <div class="dot"></div>
                </div> -->
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="features" id="features">
        <div class="container">
            <div class="section-header">
                <h2>Manage your entire community in a single system</h2>
                <p>Who is Nexcent suitable for?</p>
            </div>
            
            <div class="features-grid">
                <div class="feature-card">
                    <div class="feature-icon">
                        <svg viewBox="0 0 24 24">
                            <path d="M12,5.5A3.5,3.5 0 0,1 15.5,9A3.5,3.5 0 0,1 12,12.5A3.5,3.5 0 0,1 8.5,9A3.5,3.5 0 0,1 12,5.5M5,8C5.56,8 6.08,8.15 6.53,8.42C6.38,9.85 6.8,11.27 7.66,12.38C7.16,13.34 6.16,14 5,14A3,3 0 0,1 2,11A3,3 0 0,1 5,8M19,8A3,3 0 0,1 22,11A3,3 0 0,1 19,14C17.84,14 16.84,13.34 16.34,12.38C17.2,11.27 17.62,9.85 17.47,8.42C17.92,8.15 18.44,8 19,8M5.5,18.25C5.5,16.18 8.41,14.5 12,14.5C15.59,14.5 18.5,16.18 18.5,18.25V20H5.5V18.25M0,20V18.5C0,17.11 1.89,15.94 4.45,15.6C3.86,16.28 3.5,17.22 3.5,18.25V20H0M24,20H20.5V18.25C20.5,17.22 20.14,16.28 19.55,15.6C22.11,15.94 24,17.11 24,18.5V20Z" />
                        </svg>
                    </div>
                    <h3>Membership Organisations</h3>
                    <p>Our membership management software provides full automation of membership renewals and payments</p>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">
                        <svg viewBox="0 0 24 24">
                            <path d="M12,3L1,9L12,15L21,10.09V17H23V9M5,13.18V17.18L12,21L19,17.18V13.18L12,17L5,13.18Z" />
                        </svg>
                    </div>
                    <h3>National Associations</h3>
                    <p>Our membership management software provides full automation of membership renewals and payments</p>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">
                        <svg viewBox="0 0 24 24">
                            <path d="M12,5.5A3.5,3.5 0 0,1 15.5,9A3.5,3.5 0 0,1 12,12.5A3.5,3.5 0 0,1 8.5,9A3.5,3.5 0 0,1 12,5.5M5,8C5.56,8 6.08,8.15 6.53,8.42C6.38,9.85 6.8,11.27 7.66,12.38C7.16,13.34 6.16,14 5,14A3,3 0 0,1 2,11A3,3 0 0,1 5,8M19,8A3,3 0 0,1 22,11A3,3 0 0,1 19,14C17.84,14 16.84,13.34 16.34,12.38C17.2,11.27 17.62,9.85 17.47,8.42C17.92,8.15 18.44,8 19,8M5.5,18.25C5.5,16.18 8.41,14.5 12,14.5C15.59,14.5 18.5,16.18 18.5,18.25V20H5.5V18.25M0,20V18.5C0,17.11 1.89,15.94 4.45,15.6C3.86,16.28 3.5,17.22 3.5,18.25V20H0M24,20H20.5V18.25C20.5,17.22 20.14,16.28 19.55,15.6C22.11,15.94 24,17.11 24,18.5V20Z" />
                        </svg>
                    </div>
                    <h3>Clubs And Groups</h3>
                    <p>Our membership management software provides full automation of membership renewals and payments</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Story Section -->
    <section class="story" id="story">
        <div class="container">
            <div class="story-content">
                <div class="story-text">
                    <h2>Lorem, ipsum dolor. <span class="highlight">Lorem.</span></h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed accumsan quam vitae varius rhoncus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Integer luctus enim quis sem rhoncus, nec pulvinar ligula suscipit. Cras tristique dignissim quam vitae tempus. Nam vehicula dolor quam, ut mollis odio tincidunt sit amet.</p>
                    <a href="#" class="btn">Learn More</a>
                </div>
                <div class="story-image" >
                    <img src="img/removebg.png" alt="Hero Image">
                </div>
            </div>
        </div>
    </section>

    <!-- Stats Section -->
    <section class="stats" id="stats">
        <div class="container">
            <h2>Helping a local <span class="highlight">business reinvent itself</span></h2>
            <p>We reached here with our hard work and dedication</p>
            
            <div class="stats-grid">
                <div class="stat-item">
                    <div class="stat-icon">
                        <svg viewBox="0 0 24 24">
                            <path d="M16,13C15.71,13 15.38,13 15.03,13.05C16.19,13.89 17,15 17,16.5V19H23V16.5C23,14.17 18.33,13 16,13M8,13C5.67,13 1,14.17 1,16.5V19H15V16.5C15,14.17 10.33,13 8,13M8,11A3,3 0 0,0 11,8A3,3 0 0,0 8,5A3,3 0 0,0 5,8A3,3 0 0,0 8,11M16,11A3,3 0 0,0 19,8A3,3 0 0,0 16,5A3,3 0 0,0 13,8A3,3 0 0,0 16,11Z" />
                        </svg>
                    </div>
                    <div class="stat-number">2,245,341</div>
                    <div class="stat-label">Members</div>
                </div>
                
                <div class="stat-item">
                    <div class="stat-icon">
                        <svg viewBox="0 0 24 24">
                            <path d="M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M12,20A8,8 0 0,1 4,12A8,8 0 0,1 12,4A8,8 0 0,1 20,12A8,8 0 0,1 12,20Z" />
                        </svg>
                    </div>
                    <div class="stat-number">46,328</div>
                    <div class="stat-label">Clubs</div>
                </div>
                
                <div class="stat-item">
                    <div class="stat-icon">
                        <svg viewBox="0 0 24 24">
                            <path d="M17,4H7A5,5 0 0,0 2,9V20H20A2,2 0 0,0 22,18V9A5,5 0 0,0 17,4M10,18H4V9A3,3 0 0,1 7,6A3,3 0 0,1 10,9V18M20,18H12V9C12,7.89 11.1,7 10,7H7A5,5 0 0,0 12,4H17A3,3 0 0,1 20,7V18M8,10H5V12H8V10M8,14H5V16H8V14Z" />
                        </svg>
                    </div>
                    <div class="stat-number">828,867</div>
                    <div class="stat-label">Event Bookings</div>
                </div>
                
                <div class="stat-item">
                    <div class="stat-icon">
                        <svg viewBox="0 0 24 24">
                            <path d="M20,8H4V6H20M20,18H4V12H20M20,4H4C2.89,4 2,4.89 2,6V18A2,2 0 0,0 4,20H20A2,2 0 0,0 22,18V6C22,4.89 21.1,4 20,4Z" />
                        </svg>
                    </div>
                    <div class="stat-number">1,926,436</div>
                    <div class="stat-label">Payments</div>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="cta">
        <div class="container">
            <h2>Pellentesque suscipit fringilla libero eu.</h2>
            <p>Discover how our platform can transform your organization's membership management</p>
            <a href="#" class="btn">Get a Demo</a>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-logo">
                    <a href="index.html">
                        <svg viewBox="0 0 24 24">
                            <path d="M12,2A10,10 0 0,1 22,12A10,10 0 0,1 12,22A10,10 0 0,1 2,12A10,10 0 0,1 12,2M12,4A8,8 0 0,0 4,12A8,8 0 0,0 12,20A8,8 0 0,0 20,12A8,8 0 0,0 12,4M7,10H9A2,2 0 0,1 11,12A2,2 0 0,1 9,14H7V10M11,10H14V11.5H11V10M11,12.5H14V14H11V12.5M15,10H17A2,2 0 0,1 19,12A2,2 0 0,1 17,14H15V10M7,15H19V17H7V15Z" />
                        </svg>
                        Nexcent
                    </a>
                    <p class="footer-info">Copyright © 2023 Nexcent ltd.<br>All rights reserved</p>
                    <div class="social-links">
                        <a href="#">
                            <svg viewBox="0 0 24 24">
                                <path d="M7.8,2H16.2C19.4,2 22,4.6 22,7.8V16.2A5.8,5.8 0 0,1 16.2,22H7.8C4.6,22 2,19.4 2,16.2V7.8A5.8,5.8 0 0,1 7.8,2M7.6,4A3.6,3.6 0 0,0 4,7.6V16.4C4,18.39 5.61,20 7.6,20H16.4A3.6,3.6 0 0,0 20,16.4V7.6C20,5.61 18.39,4 16.4,4H7.6M17.25,5.5A1.25,1.25 0 0,1 18.5,6.75A1.25,1.25 0 0,1 17.25,8A1.25,1.25 0 0,1 16,6.75A1.25,1.25 0 0,1 17.25,5.5M12,7A5,5 0 0,1 17,12A5,5 0 0,1 12,17A5,5 0 0,1 7,12A5,5 0 0,1 12,7M12,9A3,3 0 0,0 9,12A3,3 0 0,0 12,15A3,3 0 0,0 15,12A3,3 0 0,0 12,9Z" />
                            </svg>
                        </a>
                        <a href="#">
                            <svg viewBox="0 0 24 24">
                                <path d="M22.46,6C21.69,6.35 20.86,6.58 20,6.69C20.88,6.16 21.56,5.32 21.88,4.31C21.05,4.81 20.13,5.16 19.16,5.36C18.37,4.5 17.26,4 16,4C13.65,4 11.73,5.92 11.73,8.29C11.73,8.63 11.77,8.96 11.84,9.27C8.28,9.09 5.11,7.38 3,4.79C2.63,5.42 2.42,6.16 2.42,6.94C2.42,8.43 3.17,9.75 4.33,10.5C3.62,10.5 2.96,10.3 2.38,10C2.38,10 2.38,10 2.38,10.03C2.38,12.11 3.86,13.85 5.82,14.24C5.46,14.34 5.08,14.39 4.69,14.39C4.42,14.39 4.15,14.36 3.89,14.31C4.43,16 6,17.26 7.89,17.29C6.43,18.45 4.58,19.13 2.56,19.13C2.22,19.13 1.88,19.11 1.54,19.07C3.44,20.29 5.7,21 8.12,21C16,21 20.33,14.46 20.33,8.79C20.33,8.6 20.33,8.42 20.32,8.23C21.16,7.63 21.88,6.87 22.46,6Z" />
                            </svg>
                        </a>
                        <a href="#">
                            <svg viewBox="0 0 24 24">
                                <path d="M12 2.04C6.5 2.04 2 6.53 2 12.06C2 17.06 5.66 21.21 10.44 21.96V14.96H7.9V12.06H10.44V9.85C10.44 7.34 11.93 5.96 14.22 5.96C15.31 5.96 16.45 6.15 16.45 6.15V8.62H15.19C13.95 8.62 13.56 9.39 13.56 10.18V12.06H16.34L15.89 14.96H13.56V21.96A10 10 0 0 0 22 12.06C22 6.53 17.5 2.04 12 2.04Z" />
                            </svg>
                        </a>
                        <a href="#">
                            <svg viewBox="0 0 24 24">
                                <path d="M19,3A2,2 0 0,1 21,5V19A2,2 0 0,1 19,21H5A2,2 0 0,1 3,19V5A2,2 0 0,1 5,3H19M18.5,18.5V13.2A3.26,3.26 0 0,0 15.24,9.94C14.39,9.94 13.4,10.46 12.92,11.24V10.13H10.13V18.5H12.92V13.57C12.92,12.8 13.54,12.17 14.31,12.17A1.4,1.4 0 0,1 15.71,13.57V18.5H18.5M6.88,8.56A1.68,1.68 0 0,0 8.56,6.88C8.56,5.95 7.81,5.19 6.88,5.19A1.69,1.69 0 0,0 5.19,6.88C5.19,7.81 5.95,8.56 6.88,8.56M8.27,18.5V10.13H5.5V18.5H8.27Z" />
                            </svg>
                        </a>
                    </div>
                </div>
                
                <div class="footer-column">
                    <h3>Company</h3>
                    <ul class="footer-links">
                        <li><a href="#">About us</a></li>
                        <li><a href="#">Blog</a></li>
                        <li><a href="#">Contact us</a></li>
                        <li><a href="#">Pricing</a></li>
                        <li><a href="#">Testimonials</a></li>
                    </ul>
                </div>
                
                <div class="footer-column">
                    <h3>Support</h3>
                    <ul class="footer-links">
                        <li><a href="#">Help center</a></li>
                        <li><a href="#">Terms of service</a></li>
                        <li><a href="#">Legal</a></li>
                        <li><a href="#">Privacy policy</a></li>
                        <li><a href="#">Status</a></li>
                    </ul>
                </div>
                
                <div class="footer-column">
                    <h3>Stay up to date</h3>
                    <form class="newsletter-form">
                        <input type="email" placeholder="Your email address">
                        <button type="submit">
                            <svg viewBox="0 0 24 24" width="24" height="24">
                                <path fill="white" d="M2,21L23,12L2,3V10L17,12L2,14V21Z" />
                            </svg>
                        </button>
                    </form>
                </div>
            </div>
            
            <div class="footer-bottom">
                <p>&copy; 2023 Nexcent ltd. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <div class="modal" id="loginModal">
        <div class="modal-content">
            <span class="close-modal">&times;</span>
            <div class="modal-header">
                <h2>Login</h2>
                <p>Welcome back! Please login to your account.</p>
            </div>
            <form class="modal-form" id="loginForm">
                <div class="form-group">
                    <label for="loginEmail">Email</label>
                    <input type="email" id="loginEmail" name="email" required>
                </div>
                <div class="form-group">
                    <label for="loginPassword">Password</label>
                    <input type="password" id="loginPassword" name="password" required>
                </div>
                <div class="form-group" style="text-align: right;">
                    <a href="#" style="color: #4CAF50; font-size: 0.9em; text-decoration: none;">Forgot password?</a>
                </div>
                <button type="submit">Login</button>
            </form>
            <div class="modal-footer">
                <p>Don't have an account? <a href="#" id="switchToSignup">Sign up</a></p>
            </div>
        </div>
    </div>
    
    <!-- Updated Signup Modal -->
    <div class="modal" id="signupModal">
        <div class="modal-content">
            <span class="close-modal">&times;</span>
            <div class="modal-header">
                <h2>Sign Up</h2>
                <p>Create an account to get started.</p>
            </div>
            <form class="modal-form" id="signupForm">
                <div class="form-group">
                    <label for="signupName">Full Name</label>
                    <input type="text" id="signupName" name="name" required>
                </div>
                <div class="form-group">
                    <label for="signupEmail">Email</label>
                    <input type="email" id="signupEmail" name="email" required>
                </div>
                <div class="form-group">
                    <label for="signupPassword">Password</label>
                    <input type="password" id="signupPassword" name="password" required>
                    <small style="display: block; margin-top: 5px; color: #666; font-size: 0.8em;">
                        Password must be at least 6 characters and include at least one number and one uppercase letter.
                    </small>
                </div>
                <div class="form-group">
                    <label for="signupConfirmPassword">Confirm Password</label>
                    <input type="password" id="signupConfirmPassword" name="confirm_password" required>
                </div>
                <div class="form-group">
                    <label style="display: flex; align-items: center; gap: 8px; font-weight: normal; cursor: pointer;">
                        <input type="checkbox" required style="width: auto;">
                        I agree to the <a href="#" style="color: #4CAF50; text-decoration: none;">Terms of Service</a> and <a href="#" style="color: #4CAF50; text-decoration: none;">Privacy Policy</a>
                    </label>
                </div>
                <button type="submit">Sign Up</button>
            </form>
            <div class="modal-footer">
                <p>Already have an account? <a href="#" id="switchToLogin">Login</a></p>
            </div>
        </div>
    </div>
    



    <!-- Login Modal 
    <div class="modal" id="loginModal">
        <div class="modal-content">
            <span class="close-modal">&times;</span>
            <div class="modal-header">
                <h2>Login</h2>
                <p>Welcome back! Please login to your account.</p>
            </div>
            <form class="modal-form" id="loginForm" action="login.php" method="post">
                <div class="form-group">
                    <label for="loginEmail">Email</label>
                    <input type="email" id="loginEmail" name="email" required>
                </div>
                <div class="form-group">
                    <label for="loginPassword">Password</label>
                    <input type="password" id="loginPassword" name="password" required>
                </div>
                <button type="submit">Login</button>
            </form>
            <div class="modal-footer">
                <p>Don't have an account? <a href="#" id="switchToSignup">Sign up</a></p>
            </div>
        </div>
    </div>-->

    <!-- Signup Modal 
    <div class="modal" id="signupModal">
        <div class="modal-content">
            <span class="close-modal">&times;</span>
            <div class="modal-header">
                <h2>Sign Up</h2>
                <p>Create an account to get started.</p>
            </div>
            <form class="modal-form" id="signupForm" action="signup.php" method="post">
                <div class="form-group">
                    <label for="signupName">Full Name</label>
                    <input type="text" id="signupName" name="name" required>
                </div>
                <div class="form-group">
                    <label for="signupEmail">Email</label>
                    <input type="email" id="signupEmail" name="email" required>
                </div>
                <div class="form-group">
                    <label for="signupPassword">Password</label>
                    <input type="password" id="signupPassword" name="password" required>
                </div>
                <div class="form-group">
                    <label for="signupConfirmPassword">Confirm Password</label>
                    <input type="password" id="signupConfirmPassword" name="confirm_password" required>
                </div>
                <button type="submit">Sign Up</button>
            </form>
            <div class="modal-footer">
                <p>Already have an account? <a href="#" id="switchToLogin">Login</a></p>
            </div>
        </div>
    </div>-->

   <!--  -->
   
    <script>
        // Hamburger Menu Toggle
        const hamburger = document.querySelector('.hamburger');
        const navLinks = document.querySelector('.nav-links');
        
        hamburger.addEventListener('click', () => {
            hamburger.classList.toggle('active');
            navLinks.classList.toggle('active');
            
            // Change hamburger to X when active
            const spans = hamburger.querySelectorAll('span');
            if (navLinks.classList.contains('active')) {
                spans[0].style.transform = 'rotate(45deg) translate(5px, 5px)';
                spans[1].style.opacity = '0';
                spans[2].style.transform = 'rotate(-45deg) translate(5px, -5px)';
            } else {
                spans[0].style.transform = 'none';
                spans[1].style.opacity = '1';
                spans[2].style.transform = 'none';
            }
        });

        // Close mobile menu when clicking outside
        document.addEventListener('click', (e) => {
            if (!hamburger.contains(e.target) && !navLinks.contains(e.target) && navLinks.classList.contains('active')) {
                hamburger.click();
            }
        });

        // Modal Functionality
        const loginBtn = document.querySelector('.login-btn');
        const signupBtn = document.querySelector('.signup-btn');
        const loginModal = document.getElementById('loginModal');
        const signupModal = document.getElementById('signupModal');
        const closeBtns = document.querySelectorAll('.close-modal');
        const switchToSignup = document.getElementById('switchToSignup');
        const switchToLogin = document.getElementById('switchToLogin');

        // Open login modal
        loginBtn.addEventListener('click', () => {
            loginModal.style.display = 'flex';
        });

        // Open signup modal
        signupBtn.addEventListener('click', () => {
            signupModal.style.display = 'flex';
        });

        // Close modals
        closeBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                loginModal.style.display = 'none';
                signupModal.style.display = 'none';
            });
        });

        // Switch between modals
        switchToSignup.addEventListener('click', (e) => {
            e.preventDefault();
            loginModal.style.display = 'none';
            signupModal.style.display = 'flex';
        });

        switchToLogin.addEventListener('click', (e) => {
            e.preventDefault();
            signupModal.style.display = 'none';
            loginModal.style.display = 'flex';
        });

        // Close modals when clicking outside
        window.addEventListener('click', (e) => {
            if (e.target === loginModal) {
                loginModal.style.display = 'none';
            }
            if (e.target === signupModal) {
                signupModal.style.display = 'none';
            }
        });

        // Carousel Functionality
        const dots = document.querySelectorAll('.dot');
        const carousel = document.querySelector('.carousel-inner');

        dots.forEach((dot, index) => {
            dot.addEventListener('click', () => {
                // Ubah active dot
                document.querySelector('.dot.active').classList.remove('active');
                dot.classList.add('active');
                
                // Tampilkan slide yang sesuai
                carousel.style.transform = `translateX(-${index * 100}%)`;
            });
        });

        // Carousel Autoplay
        let currentSlide = 0;
        const totalSlides = dots.length;

        function autoSlide() {
            currentSlide = (currentSlide + 1) % totalSlides;
            document.querySelector('.dot.active').classList.remove('active');
            dots[currentSlide].classList.add('active');
            carousel.style.transform = `translateX(-${currentSlide * 100}%)`;
        }

        // Mulai autoplay dengan interval 5 detik
        setInterval(autoSlide, 5000);

        // Form validation
        const loginForm = document.getElementById('loginForm');
        const signupForm = document.getElementById('signupForm');

        loginForm.addEventListener('submit', (e) => {
            const email = document.getElementById('loginEmail').value;
            const password = document.getElementById('loginPassword').value;
            
            if (!validateEmail(email)) {
                e.preventDefault();
                alert('Please enter a valid email address');
            }
            
            if (password.length < 6) {
                e.preventDefault();
                alert('Password must be at least 6 characters');
            }
        });

        signupForm.addEventListener('submit', (e) => {
            const email = document.getElementById('signupEmail').value;
            const password = document.getElementById('signupPassword').value;
            const confirmPassword = document.getElementById('signupConfirmPassword').value;
            
            if (!validateEmail(email)) {
                e.preventDefault();
                alert('Please enter a valid email address');
            }
            
            if (password.length < 6) {
                e.preventDefault();
                alert('Password must be at least 6 characters');
            }
            
            if (password !== confirmPassword) {
                e.preventDefault();
                alert('Passwords do not match');
            }
        });

        function validateEmail(email) {
            const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            return re.test(String(email).toLowerCase());
        }

        // Animation on scroll
        function animateOnScroll() {
            const elements = document.querySelectorAll('.feature-card, .stat-item');
            
            elements.forEach(element => {
                const elementPosition = element.getBoundingClientRect().top;
                const screenPosition = window.innerHeight / 1.3;
                
                if (elementPosition < screenPosition) {
                    element.style.opacity = '1';
                    element.style.transform = 'translateY(0)';
                }
            });
        }
        
     

        // Apply initial styles for animation
        document.querySelectorAll('.feature-card, .stat-item').forEach(element => {
            element.style.opacity = '0';
            element.style.transform = 'translateY(20px)';
            element.style.transition = 'all 0.6s ease-in-out';
        });

        // Listen for scroll
        window.addEventListener('scroll', animateOnScroll);
        // Initial check on page load
        window.addEventListener('load', animateOnScroll);
    </script>
</body>
</html>